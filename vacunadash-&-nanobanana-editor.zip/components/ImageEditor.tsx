import React, { useState, useRef } from 'react';
import { Upload, Sparkles, Image as ImageIcon, ArrowRight, X, Download, Loader2 } from 'lucide-react';
import { editImageWithGemini } from '../services/geminiService';

export const ImageEditor: React.FC = () => {
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [generatedImage, setGeneratedImage] = useState<string | null>(null);
  const [prompt, setPrompt] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) { // 5MB limit
        setError("El archivo es demasiado grande. El límite es 5MB.");
        return;
      }
      
      const reader = new FileReader();
      reader.onloadend = () => {
        setSelectedImage(reader.result as string);
        setGeneratedImage(null); // Clear previous result
        setError(null);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleGenerate = async () => {
    if (!selectedImage || !prompt.trim()) return;

    setIsLoading(true);
    setError(null);

    try {
      const result = await editImageWithGemini(selectedImage, prompt);
      setGeneratedImage(result);
    } catch (err: any) {
      setError(err.message || "Error al procesar la imagen con Gemini.");
    } finally {
      setIsLoading(false);
    }
  };

  const handleClear = () => {
    setSelectedImage(null);
    setGeneratedImage(null);
    setPrompt('');
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  return (
    <div className="animate-in fade-in duration-500 max-w-5xl mx-auto">
      
      <div className="bg-white rounded-2xl shadow-sm border border-slate-100 p-8">
        <div className="flex items-center gap-3 mb-6">
          <div className="p-3 bg-indigo-100 text-indigo-600 rounded-xl">
            <Sparkles size={24} />
          </div>
          <div>
            <h2 className="text-2xl font-bold text-slate-800">Editor Nano Banana</h2>
            <p className="text-slate-500 text-sm">Edita imágenes usando comandos de texto con Gemini 2.5 Flash</p>
          </div>
        </div>

        {/* Input Area */}
        <div className="space-y-6">
          {!selectedImage ? (
            <div 
              onClick={() => fileInputRef.current?.click()}
              className="border-2 border-dashed border-slate-300 rounded-xl p-12 flex flex-col items-center justify-center cursor-pointer hover:border-indigo-400 hover:bg-indigo-50/30 transition-all group"
            >
              <div className="p-4 bg-slate-100 rounded-full text-slate-400 group-hover:bg-white group-hover:text-indigo-500 transition-colors mb-4 shadow-sm">
                <Upload size={32} />
              </div>
              <p className="text-slate-600 font-medium">Sube una imagen para editar</p>
              <p className="text-slate-400 text-sm mt-1">PNG, JPG (Max 5MB)</p>
              <input 
                ref={fileInputRef} 
                type="file" 
                accept="image/*" 
                className="hidden" 
                onChange={handleFileChange}
              />
            </div>
          ) : (
            <div className="flex flex-col gap-6">
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-start">
                {/* Original Image */}
                <div className="relative group rounded-xl overflow-hidden border border-slate-200 bg-slate-50 aspect-square flex items-center justify-center">
                  <img src={selectedImage} alt="Original" className="w-full h-full object-contain" />
                  <div className="absolute top-3 left-3 bg-black/50 text-white text-xs px-2 py-1 rounded backdrop-blur-sm">
                    Original
                  </div>
                  <button 
                    onClick={handleClear}
                    className="absolute top-3 right-3 p-1.5 bg-white/90 text-slate-600 rounded-full shadow-sm hover:text-red-500 hover:bg-white transition-colors"
                  >
                    <X size={16} />
                  </button>
                </div>

                {/* Generated Image or Placeholder */}
                <div className="relative rounded-xl overflow-hidden border border-slate-200 bg-slate-50 aspect-square flex items-center justify-center">
                  {isLoading ? (
                    <div className="text-center p-6">
                      <Loader2 size={40} className="animate-spin text-indigo-500 mx-auto mb-3" />
                      <p className="text-slate-500 font-medium animate-pulse">Generando magia con Gemini...</p>
                    </div>
                  ) : generatedImage ? (
                    <>
                      <img src={generatedImage} alt="Generada" className="w-full h-full object-contain" />
                      <div className="absolute top-3 left-3 bg-indigo-600/90 text-white text-xs px-2 py-1 rounded backdrop-blur-sm shadow-sm flex items-center gap-1">
                        <Sparkles size={12} />
                        Editada
                      </div>
                      <a 
                        href={generatedImage} 
                        download="gemini-edit.png"
                        className="absolute bottom-4 right-4 bg-white text-slate-800 px-4 py-2 rounded-lg shadow-lg hover:bg-slate-50 font-medium text-sm flex items-center gap-2 transition-transform hover:-translate-y-0.5"
                      >
                        <Download size={16} /> Descargar
                      </a>
                    </>
                  ) : (
                    <div className="text-center p-6 text-slate-400">
                      <div className="inline-flex p-3 bg-slate-100 rounded-full mb-3">
                        <ImageIcon size={24} />
                      </div>
                      <p className="text-sm">La imagen editada aparecerá aquí</p>
                    </div>
                  )}
                </div>
              </div>

              {/* Controls */}
              <div className="bg-slate-50 p-6 rounded-xl border border-slate-200 mt-2">
                <label className="block text-sm font-semibold text-slate-700 mb-2">Instrucciones de edición</label>
                <div className="flex flex-col sm:flex-row gap-3">
                  <input
                    type="text"
                    value={prompt}
                    onChange={(e) => setPrompt(e.target.value)}
                    placeholder="Ej: 'Añade un filtro retro', 'Elimina el fondo', 'Ponle un sombrero'..."
                    className="flex-1 px-4 py-3 rounded-lg border border-slate-300 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 outline-none transition-all shadow-sm"
                    onKeyDown={(e) => e.key === 'Enter' && handleGenerate()}
                  />
                  <button
                    onClick={handleGenerate}
                    disabled={!prompt.trim() || isLoading}
                    className="bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 disabled:cursor-not-allowed text-white px-6 py-3 rounded-lg font-medium shadow-md shadow-indigo-200 transition-all flex items-center justify-center gap-2 min-w-[140px]"
                  >
                    {isLoading ? 'Procesando...' : (
                      <>
                        Generar <ArrowRight size={18} />
                      </>
                    )}
                  </button>
                </div>
                {error && (
                  <div className="mt-3 text-red-600 text-sm bg-red-50 px-3 py-2 rounded-md border border-red-100">
                    {error}
                  </div>
                )}
              </div>

            </div>
          )}
        </div>
      </div>
    </div>
  );
};